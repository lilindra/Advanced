﻿namespace Exc06.FoodShortage.Modules
{
    public interface IDable
    {
        string Id { get; }
    }
}
