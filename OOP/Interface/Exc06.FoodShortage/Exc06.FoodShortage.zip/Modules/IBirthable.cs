﻿namespace Exc06.FoodShortage.Modules
{
    public interface IBirthable
    {

        string Birth { get; }
    }
}
