﻿namespace Exc06.FoodShortage.Modules
{
    public interface IBuyer
    {
        void BuyFood();

        int Food { get; }
    }
}
