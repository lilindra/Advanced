﻿namespace Exc05.BirthdayCelebrations.Modules
{
    public interface IBirthable
    {

        string Birth { get; }
    }
}
