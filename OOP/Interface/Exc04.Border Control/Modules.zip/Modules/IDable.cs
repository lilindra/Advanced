﻿namespace Exc04.Border_Control.Modules
{
    public interface IDable
    {
        string Id { get; }
    }
}
