﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exc03.Telephony.Modules
{
    public interface IBrowseable
    {
        string Browse();
    }
}
