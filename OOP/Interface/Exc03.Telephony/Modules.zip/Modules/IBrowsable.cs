﻿namespace Exc03.Telephony.Modules
{
    internal interface IBrowsable
    {
    }
}